import { writeFileSync } from "node:fs";
import htmlMap from "../maps/entities.json" with { type: "json" };

interface TrieNode {
    /** The value, if the node has a value. */
    value?: string | undefined;
    /** A map with the next nodes, if there are any. */
    next?: Map<number, TrieNode> | undefined;
}

const htmlTrie = getTrie(htmlMap);

const serialized = serializeTrie(htmlTrie);

writeFileSync(
    new URL("../src/generated/encode-html.ts", import.meta.url),
    `// Generated using scripts/write-encode-map.ts

export default ${JSON.stringify(serialized)};
`,
);

console.log(`Done!  Data: ${serialized.length} chars`);

/**
 * Build the trie keyed by full Unicode code points (not UTF-16 char codes).
 *
 * This means astral characters (e.g. math script letters like 𝒜 = U+1D49C)
 * are stored as flat entries at their code point, instead of as children of
 * the high surrogate (U+D835).  This eliminates the large D835 surrogate
 * block and reduces the serialized data size significantly.
 * @param map
 */
function getTrie(map: Record<string, string>): Map<number, TrieNode> {
    const trie = new Map<number, TrieNode>();

    for (const [entity, decoded] of Object.entries(map)) {
        let lastMap = trie;

        // Walk all code points except the last one, creating intermediate nodes.
        let index = 0;
        while (index < decoded.length) {
            const cp = decoded.codePointAt(index)!;
            const cpLength = cp > 0xff_ff ? 2 : 1;

            // Check if this is the last code point in the sequence.
            // eslint-disable-next-line unicorn/no-break-in-nested-loop
            if (index + cpLength >= decoded.length) break;

            const next = lastMap.get(cp) ?? {};
            lastMap.set(cp, next);
            lastMap = next.next ??= new Map();
            index += cpLength;
        }

        // Set the value on the final code point.
        const lastCP = decoded.codePointAt(index)!;
        const value = lastMap.get(lastCP) ?? {};
        // The first alias in map order determines the encoded name.
        value.value ??= entity;
        lastMap.set(lastCP, value);
    }

    return trie;
}

function serializeTrie(trie: Map<number, TrieNode>): string {
    // @ts-expect-error `toSorted` requires a lib bump.
    const entries = [...trie].toSorted(
        (a: [number, TrieNode], b: [number, TrieNode]) => a[0] - b[0],
    );
    let out = "";
    let lastKey = -1;
    for (const [key, node] of entries) {
        if (lastKey === -1) {
            out += key.toString(10);
        } else {
            const diff = key - lastKey - 1;
            if (diff !== 0) out += diff.toString(10);
        }
        if (node.value) out += `${node.value};`;
        if (node.next) {
            out += `{${serializeTrie(node.next)}}`;
        }
        lastKey = key;
    }
    return out;
}
